```shell
update-alternatives --config php
```

```shell
/opt/apache-zookeeper-3.6.3-bin
~/php-zookeeper/.travis/init_zk_instances.sh
~/php-zookeeper/.travis/launch_zk_instances.sh
```
